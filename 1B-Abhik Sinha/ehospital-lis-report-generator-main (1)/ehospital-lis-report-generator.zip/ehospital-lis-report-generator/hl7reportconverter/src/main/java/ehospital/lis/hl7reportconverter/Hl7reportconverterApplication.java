package ehospital.lis.hl7reportconverter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Hl7reportconverterApplication {

	public static void main(String[] args) {
		SpringApplication.run(Hl7reportconverterApplication.class, args);
	}

}
